package io.sdses.modules.wechat.dao;

import io.sdses.modules.wechat.entity.UserOpenidEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * 
 * 
 * @author wangxd
 * @email wangxiaodong@sdses.com
 * @date 2019-06-28 17:53:52
 */
public interface UserOpenidDao extends BaseMapper<UserOpenidEntity> {
	
}
