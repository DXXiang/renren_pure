package io.sdses.modules.wechat.dao;

import io.sdses.modules.wechat.entity.UserCheckresultEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * 
 * 
 * @author wangxd
 * @email wangxiaodong@sdses.com
 * @date 2019-07-01 16:33:17
 */
public interface UserCheckresultDao extends BaseMapper<UserCheckresultEntity> {
	
}
